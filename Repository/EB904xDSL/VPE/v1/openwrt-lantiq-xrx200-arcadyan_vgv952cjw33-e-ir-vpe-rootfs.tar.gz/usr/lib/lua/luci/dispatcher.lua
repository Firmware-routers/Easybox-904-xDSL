local i=require"nixio.fs"
local m=require"luci.sys"
local o=require"luci.util"
local n=require"luci.xml"
local e=require"luci.http"
local u=require"nixio",require"nixio.util"
module("luci.dispatcher",package.seeall)
context=o.threadlocal()
uci=require"luci.model.uci"
i18n=require"luci.i18n"
_M.fs=i
local h=nil
local function r(t)
local e=require"nixio.fs"
for t,a in pairs(t)do
if a=="directory"then
local a=true
for e in(e.dir(t)or function()end)do
a=false
break
end
if a then
return false
end
elseif a=="executable"then
if e.stat(t,"type")~="reg"or not e.access(t,"x")then
return false
end
elseif a=="file"then
if e.stat(t,"type")~="reg"then
return false
end
end
end
return true
end
local function s(t,a,e)
local t=require"luci.model.uci"
if type(e)=="string"then
return(a[".type"]==e)
elseif e==true then
for e,t in pairs(a)do
if e:byte(1)~=46 then
return true
end
end
elseif type(e)=="table"then
for e,t in pairs(e)do
local e=a[e]
if type(e)=="table"then
local a=false
for o,e in ipairs(e)do
if e==t then
a=true
break
end
end
if not a then
return false
end
elseif t==true then
if e==nil then
return false
end
else
if e~=t then
return false
end
end
end
end
return true
end
local function d(e,a)
local t=require"luci.model.uci"
for o,a in pairs(a)do
local i=o:match("^@([A-Za-z0-9_%-]+)$")
if i then
local o=false
t:foreach(e,i,function(t)
if s(e,t,a)then
o=true
return false
end
end)
if not o then
return false
end
else
local t=t:get_all(e,o)
if not t or not s(e,t,a)then
return false
end
end
end
return true
end
local function s(e)
local a=require"luci.model.uci"
for t,e in pairs(e)do
if e==true then
local e=false
a:foreach(t,nil,function(t)
e=true
return false
end)
if not e then
return false
end
elseif type(e)=="table"then
if not d(t,e)then
return false
end
end
end
return true
end
local function p(t,e)
if type(t)=="table"and#t>0 then
local i=false
for t,o in ipairs(t)do
local a=false
local t=false
if type(e)=="table"and type(e[o])=="table"then
for o,e in ipairs(e[o])do
if e=="read"then
a=true
elseif e=="write"then
t=true
end
end
end
if not a and not t then
return nil
elseif t then
i=true
end
end
return i
end
return true
end
local function y(e)
if type(e.depends)~="table"then
return true
end
if type(e.depends.fs)=="table"then
local t=false
local e=(#e.depends.fs>0)and e.depends.fs or{e.depends.fs}
for a,e in ipairs(e)do
if r(e)then
t=true
break
end
end
if not t then
return false
end
end
if type(e.depends.uci)=="table"then
local t=false
local e=(#e.depends.uci>0)and e.depends.uci or{e.depends.uci}
for a,e in ipairs(e)do
if s(e)then
t=true
break
end
end
if not t then
return false
end
end
return true
end
local function s(e,a)
local t
if e.type=="call"then
t={
["type"]="call",
["module"]=a,
["function"]=e.name,
["parameters"]=e.argv
}
elseif e.type=="view"then
t={
["type"]="view",
["path"]=e.view
}
elseif e.type=="template"then
t={
["type"]="template",
["path"]=e.view
}
elseif e.type=="cbi"then
t={
["type"]="cbi",
["path"]=e.model,
["config"]=e.config
}
elseif e.type=="form"then
t={
["type"]="form",
["path"]=e.model
}
elseif e.type=="firstchild"then
t={
["type"]="firstchild"
}
elseif e.type=="firstnode"then
t={
["type"]="firstchild",
["recurse"]=true
}
elseif e.type=="arcombine"then
if type(e.targets)=="table"then
t={
["type"]="arcombine",
["targets"]={
s(e.targets[1],a),
s(e.targets[2],a)
}
}
end
elseif e.type=="alias"then
t={
["type"]="alias",
["path"]=table.concat(e.req,"/")
}
elseif e.type=="rewrite"then
t={
["type"]="rewrite",
["path"]=table.concat(e.req,"/"),
["remove"]=e.n
}
end
if e.post and t then
t.post=e.post
end
return t
end
local function r(e,a)
local i=require"nixio.fs"
local t=require"luci.util"
if type(e.nodes)=="table"then
for o,t in pairs(e.nodes)do
local e={
title=n.striptags(t.title),
order=t.order
}
if t.leaf then
e.wildcard=true
end
if t.cors then
e.cors=true
end
if t.setuser then
e.setuser=t.setuser
end
if t.setgroup then
e.setgroup=t.setgroup
end
if type(t.target)=="table"then
e.action=s(t.target,t.module)
end
if type(t.file_depends)=="table"then
for a,t in ipairs(t.file_depends)do
e.depends=e.depends or{}
e.depends.fs=e.depends.fs or{}
local a=i.stat(t,"type")
if a=="dir"then
e.depends.fs[t]="directory"
elseif t:match("/s?bin/")then
e.depends.fs[t]="executable"
else
e.depends.fs[t]="file"
end
end
end
if type(t.uci_depends)=="table"then
for t,a in pairs(t.uci_depends)do
e.depends=e.depends or{}
e.depends.uci=e.depends.uci or{}
e.depends.uci[t]=a
end
end
if type(t.acl_depends)=="table"then
for a,t in ipairs(t.acl_depends)do
e.depends=e.depends or{}
e.depends.acl=e.depends.acl or{}
e.depends.acl[#e.depends.acl+1]=t
end
end
if(t.sysauth_authenticator~=nil)or
(t.sysauth~=nil and t.sysauth~=false)
then
if t.sysauth_authenticator=="htmlauth"then
e.auth={
login=true,
methods={"cookie:sysauth"}
}
elseif o=="rpc"and t.module=="luci.controller.rpc"then
e.auth={
login=false,
methods={"query:auth","cookie:sysauth"}
}
elseif t.module=="luci.controller.admin.uci"then
e.auth={
login=false,
methods={"param:sid"}
}
end
elseif t.sysauth==false then
e.auth={}
end
if not e.action then
e.title=nil
end
e.satisfied=y(e)
a.children=a.children or{}
a.children[o]=r(t,e)
end
end
return a
end
function build_url(...)
local t={...}
local e={e.getenv("SCRIPT_NAME")or""}
local a
for a,t in ipairs(t)do
if t:match("^[a-zA-Z0-9_%-%.%%/,;]+$")then
e[#e+1]="/"
e[#e+1]=t
end
end
if#t==0 then
e[#e+1]="/"
end
return table.concat(e,"")
end
function error404(t)
e.status(404,"Not Found")
t=t or"Not Found"
local function a()
local e=require"luci.template"
e.render("error404",{message=t})
end
if not o.copcall(a)then
e.prepare_content("text/plain")
e.write(t)
end
return false
end
function error500(t)
o.perror(t)
if not context.template_header_sent then
e.status(500,"Internal Server Error")
e.prepare_content("text/plain")
e.write(t)
else
require("luci.template")
if not o.copcall(luci.template.render,"error500",{message=t})then
e.prepare_content("text/plain")
e.write(t)
end
end
return false
end
local function s()
local a=require"luci.config"
assert(a.main,"/etc/config/luci seems to be corrupt, unable to find section 'main'")
local t=a.main.lang or"auto"
if t=="auto"then
local e=e.getenv("HTTP_ACCEPT_LANGUAGE")or""
for o in e:gmatch("[%w_-]+")do
local e,i=o:match("^([a-z][a-z])[_-]([a-zA-Z][a-zA-Z])$")
if e and i then
local o="%s_%s"%{e,i:lower()}
if a.languages[o]then
t=o
break
elseif a.languages[e]then
t=e
break
end
elseif a.languages[o]then
t=o
break
end
end
end
if t=="auto"then
t=i18n.default
end
i18n.setlanguage(t)
end
function httpdispatch(a,i)
e.context.request=a
local t={}
context.request=t
local a=e.urldecode(a:getenv("PATH_INFO")or"",true)
if i then
for a,e in ipairs(i)do
t[#t+1]=e
end
end
local i
for e in a:gmatch("[^/%z]+")do
t[#t+1]=e
end
s()
local t,t=o.coxpcall(function()
dispatch(context.request)
end,error500)
e.close()
end
local function v(t,a)
if type(t)=="table"and t.type=="arcombine"and type(t.targets)=="table"then
return v((type(a)=="table"and#a>0)and t.targets[2]or t.targets[1],a)
end
if type(t)=="table"then
if type(t.post)=="table"then
local o,o,a
for o,t in pairs(t.post)do
a=e.formvalue(o)
if(type(t)=="string"and
a~=t)or
(t==true and a==nil)
then
return false
end
end
return true
end
return(t.post==true)
end
return false
end
function test_post_security()
if e.getenv("REQUEST_METHOD")~="POST"then
e.status(405,"Method Not Allowed")
e.header("Allow","POST")
return false
end
if e.formvalue("token")~=context.authtoken then
e.status(403,"Forbidden")
luci.template.render("csrftoken")
return false
end
return true
end
local function s(t,a)
local e=o.ubus("session","get",{ubus_rpc_session=t})
local i=o.ubus("session","access",{ubus_rpc_session=t})
if type(e)=="table"and
type(e.values)=="table"and
type(e.values.token)=="string"and
(not a or
o.contains(a,e.values.username))
then
uci:set_session_id(t)
return t,e.values,type(i)=="table"and i or{}
end
return nil,nil,nil
end
local function g(a,t)
local t=o.ubus("session","login",{
username=a,
password=t,
timeout=tonumber(luci.config.sauth.sessiontime)
})
local i=context.requestpath
and table.concat(context.requestpath,"/")or""
if type(t)=="table"and
type(t.ubus_rpc_session)=="string"
then
o.ubus("session","set",{
ubus_rpc_session=t.ubus_rpc_session,
values={token=m.uniqueid(16)}
})
u.syslog("info",tostring("luci: accepted login on /%s for %s from %s\n"
%{i,a or"?",e.getenv("REMOTE_ADDR")or"?"}))
return s(t.ubus_rpc_session)
end
u.syslog("info",tostring("luci: failed login on /%s for %s from %s\n"
%{i,a or"?",e.getenv("REMOTE_ADDR")or"?"}))
end
local function b(t)
local o,a=t:match("^(%w+):(.+)$")
local t,i
if o=="cookie"then
t=e.getcookie(a)
elseif o=="param"then
t=e.formvalue(a)
elseif o=="query"then
t=e.formvalue(a,true)
end
return s(t)
end
local function s(t)
local e={}
if not t.wildcard and type(t.children)=="table"then
for a,t in pairs(t.children)do
e[#e+1]={
name=a,
node=t,
order=t.order or 1000
}
end
table.sort(e,function(e,t)
if e.order==t.order then
return e.name<t.name
else
return e.order<t.order
end
end)
end
return e
end
local function f(e,a,t,n)
local i=s(e)
if#i>0 and(not n or t)then
local o={unpack(a)}
if t==false then
t=nil
end
for i,e in ipairs(i)do
o[#a+1]=e.name
local e=f(e.node,o,t,true)
if e then
return e
end
end
end
if n then
if not t or
e.action.type=="cbi"or
e.action.type=="form"or
e.action.type=="view"or
e.action.type=="template"or
e.action.type=="arcombine"
then
return a
end
end
end
local function a(e,t)
for t,o in pairs(t)do
if t=="children"then
e.children=e.children or{}
for t,o in pairs(o)do
e.children[t]=a(e.children[t]or{},o)
end
else
e[t]=o
end
end
if type(e.action)=="table"and
e.action.type=="firstchild"and
e.children==nil
then
e.satisfied=false
end
return e
end
local function s(e,a)
if type(e.children)=="table"then
for t,e in pairs(e.children)do
s(e,a)
end
end
local t
if type(e.depends)=="table"then
t=p(e.depends.acl,a["access-group"])
else
t=true
end
if t==nil then
e.satisfied=false
elseif t==false then
e.readonly=true
end
end
function menu_json(t)
local e=context.tree or createtree()
local e=r(e,{
action={
["type"]="firstchild",
["recurse"]=true
}
})
local o=createtree_json()
local e=a(e,o)
if t then
s(e,t)
end
return e
end
local function r(h)
local t=require"luci.template"
local a=luci.config.main.mediaurlbase
if not pcall(t.Template,"themes/%s/header"%i.basename(a))then
a=nil
for o,e in pairs(luci.config.themes)do
if o:sub(1,1)~="."and pcall(t.Template,
"themes/%s/header"%i.basename(e))then
a=e
end
end
assert(a,"No valid theme found")
end
local function s(i,a,e,s)
if i then
local t=getfenv(3)
local i=(type(t.self)=="table")and t.self
if type(e)=="table"then
if not next(e)then
return''
else
e=o.serialize_json(e)
end
end
e=tostring(e or
(type(t[a])~="function"and t[a])or
(i and type(i[a])~="function"and i[a])or"")
if s~=true then
e=n.pcdata(e)
end
return string.format(' %s="%s"',tostring(a),e)
else
return''
end
end
t.context.viewns=setmetatable({
write=e.write;
include=function(e)t.Template(e):render(getfenv(2))end;
translate=i18n.translate;
translatef=i18n.translatef;
export=function(e,a)if t.context.viewns[e]==nil then t.context.viewns[e]=a end end;
striptags=n.striptags;
pcdata=n.pcdata;
media=a;
theme=i.basename(a);
resource=luci.config.main.resourcebase;
ifattr=function(...)return s(...)end;
attr=function(...)return s(true,...)end;
url=build_url;
},{__index=function(a,t)
if t=="controller"then
return build_url()
elseif t=="REQUEST_URI"then
return build_url(unpack(h.requestpath))
elseif t=="FULL_REQUEST_URI"then
local t={e.getenv("SCRIPT_NAME")or"",e.getenv("PATH_INFO")}
local e=e.getenv("QUERY_STRING")
if e and#e>0 then
t[#t+1]="?"
t[#t+1]=e
end
return table.concat(t,"")
elseif t=="token"then
return h.authtoken
else
return rawget(a,t)or _G[t]
end
end})
return t
end
function dispatch(h)
local t=context
local n,w,u,c
local y=menu_json()
local a=y
local d={}
local s={}
local i={}
local l={}
for t,e in ipairs(h)do
if type(a.children)~="table"or not a.children[e]then
a=nil
break
end
if not a.children[e].satisfied then
a=nil
break
end
a=a.children[e]
n=a.auth or n
w=a.cors or w
u=a.setuser or u
c=a.setgroup or c
if type(a.depends)=="table"and type(a.depends.acl)=="table"then
for t,e in ipairs(a.depends.acl)do
local t=false
for o,a in ipairs(l)do
if a==e then
t=true
break
end
end
if not t then
l[#l+1]=e
end
end
end
d[t]=e
s[t]=e
if a.wildcard then
for e=t+1,#h do
i[e-t]=h[e]
d[e]=h[e]
end
break
end
end
local r=r(t)
t.args=i
t.path=s
t.dispatched=a
t.requestpath=t.requestpath or d
t.requestargs=t.requestargs or i
t.requested=t.requested or a
if type(n)=="table"and type(n.methods)=="table"and#n.methods>0 then
local a,i,s
for t,e in ipairs(n.methods)do
a,i,s=b(e)
if a and i and s then
break
end
end
if not(a and i and s)and n.login then
local n=e.getenv("HTTP_AUTH_USER")
local h=e.getenv("HTTP_AUTH_PASS")
if n==nil and h==nil then
n=e.formvalue("luci_username")
h=e.formvalue("luci_password")
end
if n and h then
a,i,s=g(n,h)
end
if not a then
context.path={}
e.status(403,"Forbidden")
e.header("X-LuCI-Login-Required","yes")
local e={duser="root",fuser=n}
local t,a=o.copcall(r.render_string,[[<% include("themes/" .. theme .. "/sysauth") %>]],e)
if t then
return a
end
return r.render("sysauth",e)
end
e.header("Set-Cookie",'sysauth=%s; path=%s; SameSite=Strict; HttpOnly%s'%{
a,build_url(),e.getenv("HTTPS")=="on"and"; secure"or""
})
e.redirect(build_url(unpack(t.requestpath)))
return
end
if not a or not i or not s then
e.status(403,"Forbidden")
e.header("X-LuCI-Login-Required","yes")
return
end
t.authsession=a
t.authtoken=i.token
t.authuser=i.username
t.authacl=s
end
if#l>0 then
local t=p(l,t.authacl and t.authacl["access-group"])
if t==nil then
e.status(403,"Forbidden")
return
end
if a then
a.readonly=not t
end
end
local t=(a and type(a.action)=="table")and a.action or{}
if t.type=="arcombine"then
t=(#i>0)and t.targets[2]or t.targets[1]
end
if w and e.getenv("REQUEST_METHOD")=="OPTIONS"then
luci.http.status(200,"OK")
luci.http.header("Access-Control-Allow-Origin",e.getenv("HTTP_ORIGIN")or"*")
luci.http.header("Access-Control-Allow-Methods","GET, POST, OPTIONS")
return
end
if v(t)then
if not test_post_security()then
return
end
end
if c then
m.process.setgroup(c)
end
if u then
m.process.setuser(u)
end
if t.type=="view"then
r.render("view",{view=t.path})
elseif t.type=="call"then
local a,e=o.copcall(require,t.module)
if not a then
error500(e)
return
end
local e=e[t["function"]]
assert(e~=nil,
'Cannot resolve function "'..t["function"]..'". Is it misspelled or local?')
assert(type(e)=="function",
'The symbol "'..t["function"]..'" does not refer to a function but data '..
'of type "'..type(e)..'".')
local t=(type(t.parameters)=="table"and#t.parameters>0)and{unpack(t.parameters)}or{}
for a,e in ipairs(i)do
t[#t+1]=e
end
local t,e=o.copcall(e,unpack(t))
if not t then
error500(e)
end
elseif t.type=="firstchild"then
local e=f(a,d,t.recurse)
if e then
dispatch(e)
else
r.render("empty_node_placeholder",getfenv(1))
end
elseif t.type=="alias"then
local e={}
for t in t.path:gmatch("[^/]+")do
e[#e+1]=t
end
for a,t in ipairs(i)do
e[#e+1]=t
end
dispatch(e)
elseif t.type=="rewrite"then
local e={unpack(h)}
for t=1,t.remove do
table.remove(e,1)
end
local a=1
for t in t.path:gmatch("[^/]+")do
table.insert(e,a,t)
a=a+1
end
for a,t in ipairs(i)do
e[#e+1]=t
end
dispatch(e)
elseif t.type=="template"then
r.render(t.path,getfenv(1))
elseif t.type=="cbi"then
_cbi({config=t.config,model=t.path},unpack(i))
elseif t.type=="form"then
_form({model=t.path},unpack(i))
else
local e=f(y,{},true)
if not e then
error404("No root node was registered, this usually happens if no module was installed.\n"..
"Install luci-mod-admin-full and retry. "..
"If the module is already installed, try removing the /tmp/luci-indexcache file.")
else
error404("No page is registered at '/"..table.concat(d,"/").."'.\n"..
"If this url belongs to an extension, make sure it is properly installed.\n"..
"If the extension was recently installed, try removing the /tmp/luci-indexcache file.")
end
end
end
local function s(a)
local t={}
local e=0
for o,a in ipairs(a)do
local a=i.stat(a)
if a then
t[e+1]='%x'%a.ino
t[e+2]='%x'%a.mtime
t[e+3]='%x'%a.size
e=e+3
end
end
return u.crypt(table.concat(t,"|"),"$1$"):sub(5):gsub("/",".")
end
local function r(e,a)
local o=m.process.info("uid")
local t=i.stat(e,"uid")
local i=i.stat(e,"modestr")
if o~=t or i~="rw-------"then
return nil
end
return a(e)
end
function createindex()
local e={}
local a="%s/controller/"%o.libpath()
local t,t
for t in(i.glob("%s*.lua"%a)or function()end)do
e[#e+1]=t
end
for t in(i.glob("%s*/*.lua"%a)or function()end)do
e[#e+1]=t
end
local t
if indexcache then
t="%s.%s.lua"%{indexcache,s(e)}
local e=r(t,function(e)return loadfile(e)()end)
if e then
h=e
return e
end
for e in(i.glob("%s.*.lua"%indexcache)or function()end)do
i.unlink(e)
end
end
h={}
for t,e in ipairs(e)do
local t="luci.controller."..e:sub(#a+1,#e-4):gsub("/",".")
local a=require(t)
assert(a~=true,
"Invalid controller file found\n"..
"The file '"..e.."' contains an invalid module line.\n"..
"Please verify whether the module name is set to '"..t..
"' - It must correspond to the file path!")
local e=a.index
if type(e)=="function"then
h[t]=e
end
end
if t then
local e=u.open(t,"w",600)
e:writeall(o.get_bytecode(h))
e:close()
end
end
function createtree_json()
local n=require"luci.jsonc"
local a={}
local h={
action="table",
auth="table",
cors="boolean",
depends="table",
order="number",
setgroup="string",
setuser="string",
title="string",
wildcard="boolean"
}
local e={}
local t
for t in(i.glob("/usr/share/luci/menu.d/*.json")or function()end)do
e[#e+1]=t
end
if indexcache then
t="%s.%s.json"%{indexcache,s(e)}
local e=r(t,function(e)return n.parse(i.readfile(e)or"")end)
if e then
return e
end
for e in(i.glob("%s.*.json"%indexcache)or function()end)do
i.unlink(e)
end
end
for t,e in ipairs(e)do
local e=n.parse(i.readfile(e)or"")
if type(e)=="table"then
for t,o in pairs(e)do
if type(o)=="table"then
local e=a
for t in t:gmatch("[^/]+")do
if t=="*"then
e.wildcard=true
break
end
e.children=e.children or{}
e.children[t]=e.children[t]or{}
e=e.children[t]
end
if e~=a then
for t,a in pairs(h)do
if type(o[t])==a then
e[t]=o[t]
end
end
e.satisfied=y(o)
end
end
end
end
end
if t then
local e=u.open(t,"w",600)
e:writeall(n.stringify(a))
e:close()
end
return a
end
function createtree()
if not h then
createindex()
end
local e=context
local t={nodes={},inreq=true}
e.treecache=setmetatable({},{__mode="v"})
e.tree=t
local e=setmetatable({},{__index=luci.dispatcher})
for a,t in pairs(h)do
e._NAME=a
setfenv(t,e)
t()
end
return t
end
function assign(e,a,t,o)
local e=node(unpack(e))
e.nodes=nil
e.module=nil
e.title=t
e.order=o
setmetatable(e,{__index=_create_node(a)})
return e
end
function entry(e,o,a,t)
local e=node(unpack(e))
e.target=o
e.title=a
e.order=t
e.module=getfenv(2)._NAME
return e
end
function get(...)
return _create_node({...})
end
function node(...)
local e=_create_node({...})
e.module=getfenv(2)._NAME
e.auto=nil
return e
end
function lookup(...)
local t,e=nil,{}
for t=1,select('#',...)do
local a,t=nil,tostring(select(t,...))
for t in t:gmatch("[^/]+")do
e[#e+1]=t
end
end
for a=#e,1,-1 do
local t=context.treecache[table.concat(e,".",1,a)]
if t and(a==#e or t.leaf)then
return t,build_url(unpack(e))
end
end
end
function _create_node(t)
if#t==0 then
return context.tree
end
local a=table.concat(t,".")
local e=context.treecache[a]
if not e then
local o=table.remove(t)
local t=_create_node(t)
e={nodes={},auto=true,inreq=true}
t.nodes[o]=e
context.treecache[a]=e
end
return e
end
function firstchild()
return{type="firstchild"}
end
function firstnode()
return{type="firstnode"}
end
function alias(...)
return{type="alias",req={...}}
end
function rewrite(e,...)
return{type="rewrite",n=e,req={...}}
end
function call(e,...)
return{type="call",argv={...},name=e}
end
function post_on(t,e,...)
return{
type="call",
post=t,
argv={...},
name=e
}
end
function post(...)
return post_on(true,...)
end
function template(e)
return{type="template",view=e}
end
function view(e)
return{type="view",view=e}
end
function _cbi(o,...)
local s=require"luci.cbi"
local d=require"luci.template"
local a=require"luci.http"
local n=require"luci.util"
local t=o.config or{}
local i=s.load(o.model,...)
local e=nil
local function r(t,e)
local e=n.ubus("session","access",{
ubus_rpc_session=context.authsession,
scope="uci",object=t,
["function"]=e
})
return(type(e)=="table"and e.access==true)or false
end
local h,h
for i,a in ipairs(i)do
if n.instanceof(a,s.SimpleForm)then
io.stderr:write("Model %s returns SimpleForm but is dispatched via cbi(),\n"
%o.model)
io.stderr:write("please change %s to use the form() action instead.\n"
%table.concat(context.request,"/"))
end
a.flow=t
local t=a:parse()
if t and(not e or t<e)then
e=t
end
end
local function o(e)
return type(e)=="table"and build_url(unpack(e))or e
end
if t.on_valid_to and e and e>0 and e<2 then
a.redirect(o(t.on_valid_to))
return
end
if t.on_changed_to and e and e>1 then
a.redirect(o(t.on_changed_to))
return
end
if t.on_success_to and e and e>0 then
a.redirect(o(t.on_success_to))
return
end
if t.state_handler then
if not t.state_handler(e,i)then
return
end
end
a.header("X-CBI-State",e or 0)
if not t.noheader then
d.render("cbi/header",{state=e})
end
local o
local a
local l=false
local s=true
local h={}
local n=false
for t,e in ipairs(i)do
if e.apply_needed and e.parsechain then
local t
for t,e in ipairs(e.parsechain)do
h[#h+1]=e
end
l=true
end
if e.redirect then
o=o or e.redirect
end
if e.pageaction==false then
s=false
end
if e.message then
a=a or{}
a[#a+1]=e.message
end
end
for i,e in ipairs(i)do
local d=r(e.config,"read")
local t=r(e.config,"write")
n=n or t
e:render({
firstmap=(i==1),
redirect=o,
messages=a,
pageaction=s,
parsechain=h,
readable=d,
writable=t
})
end
if not t.nofooter then
d.render("cbi/footer",{
flow=t,
pageaction=s,
redirect=o,
state=e,
autoapply=t.autoapply,
trigger_apply=l,
writable=n
})
end
end
function cbi(e,t)
return{
type="cbi",
post={["cbi.submit"]=true},
config=t,
model=e
}
end
function arcombine(e,t)
return{
type="arcombine",
env=getfenv(),
targets={e,t}
}
end
function _form(e,...)
local t=require"luci.cbi"
local o=require"luci.template"
local i=require"luci.http"
local a=luci.cbi.load(e.model,...)
local e=nil
local t,t
for a,t in ipairs(a)do
local t=t:parse()
if t and(not e or t<e)then
e=t
end
end
i.header("X-CBI-State",e or 0)
o.render("header")
for t,e in ipairs(a)do
e:render()
end
o.render("footer")
end
function form(e)
return{
type="form",
post={["cbi.submit"]=true},
model=e
}
end
translate=i18n.translate
function _(e)
return e
end
