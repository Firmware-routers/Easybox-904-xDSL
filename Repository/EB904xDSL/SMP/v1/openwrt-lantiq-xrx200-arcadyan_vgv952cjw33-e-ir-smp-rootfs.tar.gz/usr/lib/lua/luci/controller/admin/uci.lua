module("luci.controller.admin.uci",package.seeall)
local function e(e)
local t={
["Invalid command"]=400,
["Invalid argument"]=400,
["Method not found"]=404,
["Entry not found"]=404,
["No data"]=204,
["Permission denied"]=403,
["Timeout"]=504,
["Not supported"]=500,
["Unknown error"]=500,
["Connection failed"]=503
}
local t=t[e]or 200
local e=e or"OK"
luci.http.status(t,e)
if t~=204 then
luci.http.prepare_content("text/plain")
luci.http.write(e)
end
end
function action_apply_rollback()
local t=require"luci.model.uci"
local t,a=t:apply(true)
if t then
luci.http.prepare_content("application/json")
luci.http.write_json({token=t})
else
e(a)
end
end
function action_apply_unchecked()
local t=require"luci.model.uci"
local a,t=t:apply(false)
e(t)
end
function action_confirm()
local a=require"luci.model.uci"
local t=luci.http.formvalue("token")
local a,t=a:confirm(t)
e(t)
end
function action_revert()
local a=require"luci.model.uci"
local i=a:changes()
local o,t,n,n
for i,n in pairs(i)do
o,t=a:revert(i)
if t then
break
end
end
e(t or"OK")
end
